//Definiendo un arreglo nombre de errores
var arreglo = new Array();

arreglo[0]="errorEmail";
arreglo[1]="errorPassword";


function validar(){
    var entrada = new Array();

    entrada[0]=document.getElementById('email').value;
    entrada[1]=document.getElementById('password').value;

    var error = new Array();
    error[0] = "<span style='color: red'>Ingrese el email!!</span>";
    error[1] = "<span style='color: red'>Ingrese el password!!</span>";


    //Definiendo un ciclo forech
    for(i in entrada){
        var mensajeError = error[i]
        var valorArreglo = arreglo[i]
        var tamaño = entrada[i]
        //Validando campo requerido
        if(entrada[i]==""){
            document.getElementById(valorArreglo).innerHTML = mensajeError;
        }

        //Validar correo
        else if (i==0){
                var arroba = entrada[i].indexOf("@");
                var punto = entrada[i].lastIndexOf(".");

                if(arroba<1 || punto < arroba + 2 || entrada[i].length<punto+2){
                    document.getElementById('errorEmail').innerHTML =
                    "<span style='color: red'>Ingrese un email válido!!</span>";
                }
                else {
                    document.getElementById('errorEmail').innerHTML =
                    "Campo válido!!";
                }
        }
        //validar tamaño password
        else if(i==1){
            if(tamaño.length > 7 && tamaño.length < 19 ){
                document.getElementById('errorPassword').innerHTML =
                    "Tamaño Correcto";
            }else{
                document.getElementById('errorPassword').innerHTML =
                    "<span style='color: red'>Debe tener entre 8 y 20 caracteres</span>";
            }

        }
        else {
            document.getElementById(valorArreglo).innerHTML =
                "Campo válido!!";
        }

    }



}

function validarTodos(){
    var contador = 0;
    for(i=0; i<2; i++){
        var valorArreglo = arreglo[i];
        if( document.getElementById(valorArreglo).innerHTML == "Campo válido!!")
        {
            contador++;
            location.href="ropamujer.html"
        }
    }
    if(contador == 2){
        document.getElementById('mensajefinal').innerHTML = "Formulario validado!!"
    }
}

function irRegistro(){
    location.href = "registrarse.html"
}